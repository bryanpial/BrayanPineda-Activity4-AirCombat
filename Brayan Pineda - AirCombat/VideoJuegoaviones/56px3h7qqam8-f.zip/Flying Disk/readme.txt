Created by Herminio Nieves @2014
 for comercial and non comercial use.
includes everything you see,do not resale or bundle in
other packages.format in wavefront,see renders for reference,if you use
Daz 3d you will be able to upload the product loaded with texures.remember
to decompress first then import the decompress file.
non movable parts.It is appreciated if credits are present,if you modify this model
please do not put it for sales it is a violation of copyright you can contact me at 
info@hns3d.com or nievesherminio@yahoo.com or nieves_herminio@yahoo.com
Visit us at hns3d.com or herminionieves.selz.com
Jesus Saves!